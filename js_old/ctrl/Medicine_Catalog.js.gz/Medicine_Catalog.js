function addMedicine(){
    $("#medicinesubmit")[0].reset();
    $('#exdate').addClass('col-md-6');
     $('#exdate').removeClass('col-md-12');
    $('#qnt').show();
    $('.error-msg-box').text('');
    $('.rmv').removeClass('adminred');
}

$(document).ready(function(){
    
    $("#name").focusout(function(){
        if($(this).val()===''){
            $(this).addClass('adminred');
            $('#nameerr').text("Please Enter Medicine Name!");
        }
        else{
             $(this).removeClass('adminred');
             $('#nameerr').text("");
        }
    });
    
    $("#expiry_date").focusout(function(){
        if($(this).val()===''){
            $(this).addClass('adminred');
            $('#expiry_dateerr').text("Please Select Expiry Date!");
        }
        else{ 
             $(this).removeClass('adminred');
             $('#expiry_dateerr').text("");
        }
    });
    
    $("#quantity").focusout(function(){
        if($(this).val()===''){
            $(this).addClass('adminred');
            $('#quantityerr').text("Please Enter Quantity!");
        }
        else{
             $(this).removeClass('adminred');
             $('#quantityerr').text("");
        }
    });
    
    $("#medicinesubmit").submit(function(event){
        event.preventDefault();
        var valid=true;
        var alphanumeric = /^[a-zA-Z0-9\s]+$/;
        var reg_letters = /^[a-zA-Z\s]+$/;
        var reg_numbers=/^[0-9]*$/;
        var reg_alphanumeric=/^[a-zA-Z0-9 ]*$/;
        var comma_string=/^[a-zA-Z, ]+$/;
        
        
       if($("#name").val()===''){
             $("#name").addClass('adminred');
            $('#nameerr').text("Please Enter Medicine Name!");
            valid=false;
        }
        else if(!$("#name").val().match(reg_letters)){
            $("#name").addClass('adminred');
            $('#nameerr').text("Please Enter Alphabets only!");
            valid=false;
        }
        else{
            $("#name").removeClass('adminred');
             $('#nameerr').text("");
        }
        
        if($("#brand").val()!==''){
            if(!$("#brand").val().match(comma_string)){
            $("#brand").addClass('adminred');
            $('#branderr').text("Please Enter Alphabets only!");
            valid=false;
            }
        else{
            $("#brand").removeClass('adminred');
             $('#branderr').text("");
            }
        }
        
        if($("#generic_name").val()!==''){
           if(!$("#generic_name").val().match(reg_letters)){
            $("#generic_name").addClass('adminred');
            $('#generic_nameerr').text("Please Enter Alphabets only!");
            valid=false;
        }
        else{
            $("#generic_name").removeClass('adminred');
             $('#generic_nameerr').text("");
            }
        }
        if($("#dosage").val()!==''){
             if(!$("#dosage").val().match(reg_alphanumeric)){
            $("#dosage").addClass('adminred');
            $('#dosageerr').text("Please Enter Alphabets and Numbers only!");
            valid=false;
        }
        else{
            $("#dosage").removeClass('adminred');
            $('#dosageerr').text("");
            }
       }
        
        if($("#batch_number").val()!==''){
            if(!$("#batch_number").val().match(reg_alphanumeric)){
            $("#batch_number").addClass('adminred');
            $('#batch_numbererr').text("Please Enter Alphabets and Numbers only!");
            valid=false;
        }
        else{
            $("#batch_number").removeClass('adminred');
             $('#batch_numbererr').text("");
            }
        }
        if($("#expiry_date").val()===''){
             $("#expiry_date").addClass('adminred');
            $('#expiry_dateerr').text("Please Select Expiry Date!");
            valid=false;
        }
        else{
            $("#expiry_date").removeClass('adminred');
             $('#expiry_dateerr').text("");
        }
        
        if($("#indications").val()!==''){
            
         if(!$("#indications").val().match(reg_alphanumeric)){
            $("#indications").addClass('adminred');
            $('#indicationserr').text("Please Enter Alphabets and Numbers only!");
            valid=false;
        }
        else{
            $("#indications").removeClass('adminred');
             $('#indicationserr').text("");
        }
        }
        
        if($("#quantity").val()===''){
             $("#quantity").addClass('adminred');
            $('#quantityerr').text("Please Enter Quantity!");
            valid=false;
        }
        else if(!$("#quantity").val().match(reg_numbers)){
            $("#quantity").addClass('adminred');
            $('#quantityerr').text("Please Enter Numbers only!");
            valid=false;
        }
        else{
            $("#quantity").removeClass('adminred');
             $('#quantityerr').text("");
        }       
        
        
    if(valid===true){
        var ajaxurl;
    
     var formData = new FormData();
     formData.append('id',$("#medicineid").val()),
     formData.append('name',$("#name").val()),
     formData.append('brand',$("#brand").val()),
     formData.append('generic_name',$("#generic_name").val()),
     formData.append('dosage',$("#dosage").val()),
     formData.append('batch_number',$("#batch_number").val()),
     formData.append('expiry_date',$("#expiry_date").val()),
     formData.append('indications',$("#indications").val()),
     formData.append('quantity',$("#quantity").val())
      
     if($("#medicineid").val()===''){
         ajaxurl=site_url + 'ctrl/MedicineCatalog/insertMedicineCatalog';
     }else{
         ajaxurl=site_url + 'ctrl/MedicineCatalog/updateMedicineCatalog';
     }

    $.ajax({
            url:ajaxurl,
            type: 'POST',
            contentType: false,
            data: formData,
            processData: false,
            success: function(response) {
                 
                 var res = JSON.parse(response);
                    if(res['status']){
                         $('#medicine_sucess').html(res['response']['messages'] );
                         $('#squarespaceModal').modal('hide');
                         window.location.reload();
                    }else if(res['status']===''){
                         $('#medicine_error').html(res['response']['messages'] );
                         $('#squarespaceModal').modal('hide');
                    } 
                    else{
                        $('#nameerr').text(res['name']);
                        $('#quantityerr').text(res['quantity']);
                        $('#expiry_dateerr').text(res['expiry_date']);
                    }
            },
            error: function (xhr, status, error) {
                // alert(xhr.responseText);
                console.log(" xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: " + error);
            }

        });
    }
    });
    
});

function editmedicine(id ){
    // alert($("#"+id+"_1").val());
     //console.log($('#id').val($("#"+id+"_1").text()));
     $('#lineModalLabel').html('Edit Medicine Catalog');
     $('#qnt').hide();
     $('#exdate').removeClass('col-md-6');
     $('#exdate').addClass('col-md-12');
     $('.error-msg-box').text('');
     $('.rmv').removeClass('adminred');
     $('#squarespaceModal').modal('show');
    
     $('#medicineid').val(id);
     $('#name').val($("#"+id+"_2").text());
     $('#brand').val($("#"+id+"_3").text());
     $('#generic_name').val($("#"+id+"_4").text());
     $('#dosage').val($("#"+id+"_5").text());
     $('#batch_number').val($("#"+id+"_6").text());
     $('#expiry_date').val($("#"+id+"_7").text());
     $('#indications').val($("#"+id+"_8").text());
     $('#quantity').val($("#"+id+"_9").text());
     $('#stock').val($("#"+id+"_10").text());
     
    }
    
    
function deletemedicine(id,event){
    //event.preventDefault();
    var formData = new FormData();
    formData.append('id',id);
    
    var x = confirm("Are you sure you want to delete?");
    if (x) {
      $.ajax({
            url:site_url + 'ctrl/medicineCatalog/deleteMedicineCatalog',
            type: 'POST',
            contentType: false,
            data: formData,
            processData: false,
            success: function(response) {
              
                var json = JSON.parse(response);  
                 
                if(json['status']==1){
                    $("#sucess_msg").show();
                    $("#sucess_msg").html(json['response']['messages']).fadeOut('5000');
                    $("#medicine"+id).hide();
                }else{
                    $("#error_msg").show();
                    $("#error_msg").html(json['response']['messages']).fadeOut('5000');
                }
                
            },
            error: function (xhr, status, error) {
                // alert(xhr.responseText);
                console.log(" xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: " + error);
            }

        });
    }
    
}