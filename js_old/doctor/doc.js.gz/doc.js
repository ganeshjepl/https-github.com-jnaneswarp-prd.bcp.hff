/* global angular, site_url */

//Medical Record Page
var myVar;
function loader() {
    myVar = setTimeout(showPage, 1500);
}
function loading(){
    
    	$.blockUI({ css: { 
            border: 'none', 
            padding: '15px', 
            backgroundColor: '#000', 
            '-webkit-border-radius': '10px', 
            '-moz-border-radius': '10px', 
            opacity: .5, 
            color: '#fff' 
        } }); 
 
        

}
function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
// End Medical Record Page
// 
function docpro(){
	$('#newpwd').hide();
	$('#editprofile').show();
}
function newpassword(){
	$('#editprofile').hide();
	$('#newpwd').show();
}





$(document).ready(function() {
    doctor.drawSticky();
    
//    doctor.getPrescriptionPopup(1);
//    doctor.getMedicineCatalog();
});
var app = angular.module('medicines_catalog_app', []);

app.controller('country', function ($scope, $http) {
    $scope.countries = [300];
    
    $scope.search = function () {
        var country=$("#country").val();
        $scope.RandomValue = country;
        
        $http({
            method: "get",
            url: site_url + 'api/mobile/v1/Country/searchCountry?name=' + $scope.RandomValue
        }).then(function (response, status) {

            $scope.country = JSON.stringify(response.data);
            var array = JSON.parse($scope.country);
//     var arr = jQuery.makeArray(array.response.countryData);
            var len = Object.keys(array.response.countryData).length;
            var i = 0;
            $scope.countries.length = 0;
            while (i < len) {
                $scope.countries.push(array.response.countryData[i]);
                i++;

            }
        }, function myError(response) {
            $scope.err = response.statusText;

        });

    };
});



var doctor = {
    setMedicineDosage: function(val,id){
        
        $('#dosage'+$('#'+id).closest('tr').attr('data-id')).val($('#'+id).find(':selected').attr('data-dosage'));
        
    },
    drawSticky: function(){
        var sticky_ids    =   [];
        $('input[type="hidden"].stickyImageid').each(function () {
            sticky_ids.push($(this).val());
            
        });
        $.each(sticky_ids, function( index, value ) {
            var sticky_data = JSON.parse($('#sticky_coordinates'+value+'').val());
            $.each(sticky_data, function( index, coordinate ) {
                $("#sticky_"+value).append('<img class="mark" src="http://localhost/hff/pics/img.png" style="position:absolute;left:'+coordinate.x+'px; top:'+coordinate.y+'px; z-index:2;" >');
            });
        });
         
    },
    redirectMrDetails: function(pid){
        $('#pid').val(pid);
        $( "#redirectMrRecord" ).submit();
    },
    savePrescription: function(){
        try{
            var data   =   [];
            $.each($("#prescription_saving_doc tr"), function() {
            var rowid   =   $(this).data("id");
            if(rowid > 0){
                    if($('#medicine'+rowid+'').val() == 0)
                        throw{'msg':'Please select Medicine','elt':'#medicine'+rowid+''}
                    if($('#quantity'+rowid+'').val() == '')
                        throw{'msg':'Please enter quantity','elt':'#quantity'+rowid+''}
                    if($('#quantity'+rowid+'').val() == 0)
                        throw{'msg':'Quantity should be atleast 1','elt':'#quantity'+rowid+''}
                    if($('#timing'+rowid+'').val() == '')
                        throw{'msg':'Please enter timings','elt':'#timing'+rowid+''}
                    if($('#days'+rowid+'').val() == 0)
                        throw{'msg':'Days should be atlease 1','elt':'#days'+rowid+''}
                        
                    var Array   =   {
                        'medicine_id'   :   $('#medicine'+rowid+'').val(),
                        'quantity'      :   $('#quantity'+rowid+'').val(),
                        'timing_ids'        :   $('#timing'+rowid+'').val(),
                        'days'          :   $('#days'+rowid+'').val(),
                        'visit_id'          :   $('#hidden_visit_id').val(),
                        'bcp_id'          :   $('#hidden_bcp_id').val(),
                        'medicine_name'          :   $('#medicine'+rowid+'').val(),
                        'prescription_request_id'          :   $('#hidden_prescription_request_id').val(),
                    };
                    data.push(Array);
                }
            });
            
            
            loading();
            $.ajax({
            url:site_url + 'doctor/Doctor/savePrescription',
            type: 'POST',
            data: {
                'data'  :   data
            },
            dataType:'json',
            success: function(data) {
                    
                if(!data.error){
//                      $.unblockUI;  
//                    document.getElementById("loader").style.display = "none";
                    $('#prescription1').modal('hide');
                    $('#prescription_popup').html('');
                    location.reload();
                }
                              
            },
            

        });
            
        
        }
        catch(e)
         {
            alert(e.msg);
            $(e.elt).focus();
            return false;
         }
        
    },
    addPrescription: function(){
        try{
            var data   =   [];
            if($('#id_bcp_list').val() == 0)
                throw{'msg':'Please select BCP','elt':'#id_bcp_list'}
            
            if($('#id_patient').val() == 0){
                if($('#name').val() == '')
                    throw{'msg':'Please enter Name','elt':'#name'}
                if($('#gender').val() == '')
                    throw{'msg':'Please enter gender','elt':'#gender'}
                if($('#age').val() == '')
                    throw{'msg':'Please enter age','elt':'#age'}
                if($('#village').val() == '')
                    throw{'msg':'Please enter village','elt':'#village'}
                if($('#contact').val() == '')
                    throw{'msg':'Please enter contact number','elt':'#contact'}
            }
            
            var header_data =   {
                'bcp_id'    :   $('#id_bcp_list').val(),
                'id_patient'    :   $('#id_patient').val(),
                'incident_type'    :   $('input[name=incident_type]:checked').val(),
                'name'    :   $('#name').val(),
                'gender'    :   $('#gender').val(),
                'age'    :   $('#age').val(),
                'village'    :   $('#village').val(),
                'contact'    :   $('#contact').val(),
            };
            
            $.each($("#prescription_add_table tr"), function() {
            var rowid   =   $(this).data("id");
            if(rowid > 0){
                    if($('#medicine'+rowid+'').val() == 0)
                        throw{'msg':'Please select Medicine','elt':'#medicine'+rowid+''}
                    if($('#quantity'+rowid+'').val() == '')
                        throw{'msg':'Please enter quantity','elt':'#quantity'+rowid+''}
                    if($('#quantity'+rowid+'').val() == 0)
                        throw{'msg':'Quantity should be atleast 1','elt':'#quantity'+rowid+''}
                    if($('#timing'+rowid+'').val() == '')
                        throw{'msg':'Please enter timings','elt':'#timing'+rowid+''}
                    if($('#days'+rowid+'').val() == 0)
                        throw{'msg':'Days should be atlease 1','elt':'#days'+rowid+''}
                        
                    var Array   =   {
                        'medicine_id'   :   $('#medicine'+rowid+'').val(),
                        'quantity'      :   $('#quantity'+rowid+'').val(),
                        'timing_ids'        :   $('#timing'+rowid+'').val(),
                        'days'          :   $('#days'+rowid+'').val(),
                        'visit_id'          :   $('#hidden_visit_id').val(),
                        'bcp_id'          :   $('#hidden_bcp_id').val(),
                        'medicine_name'          :   $('#medicine'+rowid+':selected').text(),
                        'prescription_request_id'          :   $('#hidden_prescription_request_id').val(),
                    };
                    data.push(Array);
                }
            });
            
            
//            loading();
            $.ajax({
            url:site_url + 'doctor/Doctor/addPrescription',
            type: 'POST',
            data: {
                'data'  :   data,
                'header_data'  :   header_data,
            },
            dataType:'json',
            success: function(data) {
                    
                if(!data.error){
//                      $.unblockUI;  
//                    document.getElementById("loader").style.display = "none";
                    $('#prescription1').modal('hide');
                    $('#prescription_popup').html('');
                    location.reload();
                }
                              
            },
            

        });
            
        
        }
        catch(e)
         {
            alert(e.msg);
            $(e.elt).focus();
            return false;
         }
        
    },
    getMedicineCatalog: function(search){
        $.ajax({
            url:site_url + 'doctor/Doctor/getMedicineCatalog',
            type: 'GET',
            data: {
                'search'    :   search,
            },
            dataType:'json',
            success: function(data) {
                
                if(!data.error){
                    console.log(data);
                    $('#prescription_popup').html(data.payload);
                    $('#prescription1').modal('show');
                }
                              
            },
            

        });
    },
    getPrescriptionPopup: function(id){
        $.ajax({
            url:site_url + 'doctor/Doctor/getPrePrescriptionData',
            type: 'GET',
            data: {
                'id'    :   id,
            },
            dataType:'json',
            success: function(data) {
                if(!data.error){
                    
                    $('#prescription_popup').html(data.payload);
                    $('#prescription1').modal('show');
                    
                    $('#presc_add_new_button').trigger("click");
//                    $compile($('#prescription_popup').contents())($scope);
                }
                              
            },
            

        });
    },
    getAddPrescriptionPopup: function(id){
        
        $.ajax({
            url:site_url + 'doctor/Doctor/getPrePrescriptionDataForAdd',
            type: 'GET',
            data: {
                'id'    :   id,
            },
            dataType:'json',
            success: function(data) {
                if(!data.error){
                    
                    $('#prescription_popup_add').html(data.payload);
                    
                    $('#prescription2').modal('show');
                    doctor.getBcpList();
                    $('#presc_add_new_button_add').trigger("click");
                }
                              
            },
            

        });
    },
    getBcpList: function(id){
        
        $.ajax({
            url:site_url + 'doctor/Doctor/getAssignedBcpList',
            type: 'GET',
            data: {
                'id'    :   id,
            },
            dataType:'json',
            success: function(data) {
                
                if(!data.error){
                    
                    $('#id_bcp_list').html('<option value="0">-- BCP --</option>'+data.payload);
                    $('.select2').select2();
//                    $('#prescription2').modal('show');
                    
//                    $('#presc_add_new_button').trigger("click");
//                    $compile($('#prescription_popup').contents())($scope);
                }
                              
            },
            

        });
    },
    getAssignedPatients: function(id){
        
        $.ajax({
            url:site_url + 'doctor/Doctor/getAssignedPatients',
            type: 'POST',
            data: {
                'id'    :   id,
            },
            dataType:'json',
            success: function(data) {
                
                if(!data.error){
                    
                    $('#id_patient').html('<option value="0">-- Patient --</option>'+data.payload);
                    $('.select2').select2();
//                    $('#prescription2').modal('show');
                    
//                    $('#presc_add_new_button').trigger("click");
//                    $compile($('#prescription_popup').contents())($scope);
                }
                              
            },
            

        });
    },
    
    addRows: function(tableid){	
        
	// Dynamic Rows Code
        // Get max row id and set new id
	var newid = 0;
	$.each($("#"+tableid+" tr"), function() {
		
		if (parseInt($(this).data("id")) > newid) {
			newid = parseInt($(this).data("id"));
		}
	});
	newid++;

	var tr = $("<tr></tr>", {
		id : "addr" + newid,
		"data-id" : newid
	});

	// loop through each td and create new elements with
	// name of newid
	$.each($("#"+tableid+" tbody tr:nth(0) td"), function() {
		var cur_td = $(this);

		var children = cur_td.children();

		// add new td and element if it has a nane
		if ($(this).data("name") != undefined) {
			var td = $("<td></td>", {
				"data-name" : $(cur_td).data("name"),
			});

			var c = $(cur_td).find(
					$(children[0]).prop('tagName')).clone()
					.val("");
			c.attr("name", $(cur_td).data("name") + newid);
			c.attr("id", $(cur_td).data("name") + newid);
			c.appendTo($(td));
			td.appendTo($(tr));
		} else {
			var td = $("<td></td>", {
				'text' : $("#"+tableid+" tr").length
			}).appendTo($(tr));
		}
	});

	// add delete button and td
	/*
	 * $("<td></td>").append( $("<button class='btn
	 * btn-danger glyphicon glyphicon-remove row-remove'></button>")
	 * .click(function() { $(this).closest("tr").remove(); })
	 * ).appendTo($(tr));
	 */

	// add the new row
	$(tr).appendTo($("#"+tableid));

	$(tr).find("td button.row-remove").on("click",
			function() {
				$(this).closest("tr").remove();
			});
                        $('.select2').select2();
                        
    },
};









// Script to open and close sidebar
function w3_open() {
	document.getElementById("mySidebar").style.display = "block";
	document.getElementById("myOverlay").style.display = "block";
}

function w3_close() {
	document.getElementById("mySidebar").style.display = "none";
	document.getElementById("myOverlay").style.display = "none";
}

function openNav() {
	document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
	document.getElementById("mySidenav").style.width = "0";
}


/*//for tool-tip
$(document).ready(function() {
	$('[data-toggle="tooltip"]').tooltip();
});*/


$(document).ready(function(){
	
	n =  new Date();
	y = n.getFullYear();
	m = n.getMonth() + 1;
	d = n.getDate();
	var date = m + "/" + d + "/" + y;
	$(".currentdate").text(date);
	
	
	
	$(".contact-toggle").click(function(){
		$(".contact-toggle").hide();
	    $(".contact-box").show(); /*('slide', {direction: 'right'}, 1000);*/
    });
	
	$(".retake").click(function(){
		$(".contact-box").hide(); /*('slide', {direction: 'right'}, 1000); */
	    $(".contact-toggle").show();
	});
	
	$(".submit").click(function(){
		$(".contact-box").hide(); /*('slide', {direction: 'right'}, 1000); */
	    $(".contact-toggle").show();
	});
	
	
	//for tool-tip	
	$('[data-toggle="tooltip"]').tooltip();
	//for end tool-tip	
	
					columnChart();

					function columnChart() {
						var item = $('.chart', '.column-chart').find('.item'), itemWidth = 100 / item.length;
						item.css('width', itemWidth + '%');

						$('.column-chart')
								.find('.item-progress')
								.each(
										function() {
											var itemProgress = $(this), itemProgressHeight = $(
													this).parent().height()
													* ($(this).data('percent') / 100);

											console
													.log($(this)
															.data('percent'));
											console.log(itemProgressHeight);

											itemProgress.css('height',
													itemProgressHeight);
										});
					}
					;
				});



// for displaying a particular date

function myFunction() {
	var x = document.getElementById("myDate").value;
	document.getElementById("demo").innerHTML = x;
}

// for filtering table data of single column with multiple tables
function myFunction2() {

	var input, filter, table, tr, td, i;
	input = document.getElementById("myInput");
	filter = input.value.toUpperCase();
	table = document.getElementById("myTable");
	tr = table.getElementsByTagName("tr");
	for (i = 0; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[0];
		if (td) {
			if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
				tr[i].style.display = "";
			} else {
				tr[i].style.display = "none";
			}
		}
	}

	if ($('#myTable tr:visible').length == 1) {
		$('#myTable').hide();
	} else {
		$('#myTable').show();
	}
}
function myFunction20() {

	var input, filter, table, table2, tr, tr2, td, td2, i, j;
	input = document.getElementById("myInput");

	filter = input.value.toUpperCase();

	table = document.getElementById("myTable");
	tr = table.getElementsByTagName("tr");

	table2 = document.getElementById("myTable2");
	tr2 = table2.getElementsByTagName("tr");

	for (i = 0, j = 0; (i < tr.length) || (j < tr2.length); i++, j++) {

		td = tr[i].getElementsByTagName("td")[0];
		if (td) {
			if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {

				tr[i].style.display = "";

				$('#myTable tbody tr.header').show();
				$('#myTable').show();

			} else {
				tr[i].style.display = "none";

			}
		}

		td2 = tr2[j].getElementsByTagName("td")[0];
		if (td2) {
			if (td2.innerHTML.toUpperCase().indexOf(filter) > -1) {

				tr2[j].style.display = "";

				$('#myTable2 tbody tr.header').show();
				$('#myTable2').show();

			} else {
				tr2[j].style.display = "none";

			}
			console.log($('#myTable2 tr:visible').length);
		}

	}
	if ($('#myTable tr:visible').length == 1) {
		$('#myTable tbody tr.header').hide();
		$('#myTable').hide();
	}
	if ($('#myTable2 tr:visible').length == 1) {
		$('#myTable2 tbody tr.header').hide();
		$('#myTable2').hide();
	}
	if ($.trim(filter) == '') {
		$('#myTable').hide();
		$('#myTable2').hide();
	}

}



